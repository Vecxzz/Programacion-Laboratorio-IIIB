// 2. Crea un proyecto
console.log("Ejercicio 2: corriendo desde TypeScript");



// 3. Crea variables de diferentes tipos de datos (string, number, boolean, Date). Muestra sus valores en el HTML
let texto: string = "Hola, TypeScript!";
let numero: number = 123;
let booleano: boolean = true;
let fecha = (new Date()).getDate() + '/' + ((new Date()).getMonth() + 1) + '/' + (new Date()).getFullYear();

const variables = document.getElementById('variables');
if (variables) {
    variables.innerHTML += `<p>Texto: ${texto}</p>`;
    variables.innerHTML += `<p>Número: ${numero}</p>`;
    variables.innerHTML += `<p>Booleano: ${booleano}</p>`;
    variables.innerHTML += `<p>Fecha: ${fecha}</p>`;
}



// 4. Crea una función que convierta un número a una cadena de texto. Muestra el resultado en el HTML
const convertir = document.getElementById('convertir');

function convertirCadena() {
    return (prompt("Ingresa un número"))?.toString();
}

if (convertir) {
    convertir.innerHTML += `<p>Número convertido a cadena: ${convertirCadena()}</p>`;
}



// 5. Crea un array de números y una función que sume todos los elementos del array. Muestra la suma en el HTML
const sumar = document.getElementById('sumar');
let numeros: number[] = [10, 10, 2];

function sumarNumeros(numeros: number[]): number {
    let total = 0;
  
    for (let numero of numeros) {
      total += numero;
    }
  
    return total;
}

if (sumar) {
    sumar.innerHTML += `<p>Suma del array: ${sumarNumeros(numeros)}</p>`
}



// 6. Crea un objeto que representa a un estudiante con nombre, edad y curso. Muestra al estudiante y sus propiedades en el HTML
const objetoEstudiante = document.getElementById('objetoEstudiante');

type Estudiante = {
    nombre: string;
    edad: number;
    curso: string;
}

let estudiante1: Estudiante = {
    nombre: "Juan",
    edad: 20,
    curso: "Matemáticas"
}

if (objetoEstudiante) {
    objetoEstudiante.innerHTML += `<p>Estudiante: ${estudiante1.nombre}</p>`;
    objetoEstudiante.innerHTML += `<p>Edad: ${estudiante1.edad}</p>`;
    objetoEstudiante.innerHTML += `<p>Curso: ${estudiante1.curso}</p>`;
}



// 7. Define un "type" personalizado para representar una dirección con calle, ciudad y código postal. Usa este tipo para crear una dirección y muéstrala en el HTML
const objetoDireccion = document.getElementById('objetoDireccion');

type Direccion = {
    calle: string;
    ciudad: string;
    codigoPostal: string;
}

let direccion1: Direccion = {
    calle: "Av. Principal",
    ciudad: "Mendoza",
    codigoPostal: "M5523"
}

if (objetoDireccion) {
    objetoDireccion.innerHTML += `<p>Dirección: ${direccion1.calle}, ${direccion1.ciudad}, ${direccion1.codigoPostal}</p>`;
}



// 8. Define una interfaz para un usuario que tenga nombre, correo y un método para saludar. Implementa esta interfaz en un objeto y muestra el saludo en el HTML
const interfazUsuario = document.getElementById('interfazUsuario') as HTMLElement;

interface Usuario {
    nombre: string;
    correo: string;
    saludar(): string;
}

class UsuarioImplementado implements Usuario {
    nombre: string;
    correo: string;

    constructor(nombre: string, correo: string) {
        this.nombre = nombre;
        this.correo = correo;
    }

    saludar(): string {
        return `Hola, mi nombre es ${this.nombre}`;
    }
}

let usuario1: Usuario = new UsuarioImplementado("Uriel", "urielvera47@gmail.com");

if (interfazUsuario) {
    interfazUsuario.innerHTML += `<p>${usuario1.saludar()}</p>`;
}



// 9. Crea una clase 'Persona' con propiedades para nombre y edad. Implementa un método para presentarse y muestra el resultado en el HTML
const clasePersona = document.getElementById('clasePersona') as HTMLElement;

class Persona {
    nombre: string;
    edad: number;

    constructor(nombre: string, edad: number) {
        this.nombre = nombre;
        this.edad = edad;
    }

    presentarse(): string {
        return `Hola, mi nombre es ${this.nombre} y tengo ${this.edad} años`;
    }
}

let persona1 = new Persona("Uriel", 19);

if (clasePersona) {
    clasePersona.innerHTML += `<p>${persona1.presentarse()}</p>`;
}



// 10. Crea una clase genérica 'Caja' que almacena un valor de tipo genérico. Implementa un método para obtener el valor y muestra los resultados en el HTML
const claseCaja = document.getElementById('claseCaja') as HTMLElement;

class Caja<T> {
    private valor: T;

    constructor(valor: T) {
        this.valor = valor;
    }

    obtenerValor(): T {
        return this.valor
    }
}

let cajaDeTexto: Caja<string> = new Caja<string>("Mensaje Secreto");
let cajaDeNumero: Caja<number> = new Caja<number>(22);

if (claseCaja) {
    claseCaja.innerHTML += `<p>Contenido de Caja de Texto: ${cajaDeTexto.obtenerValor()}</p>`;
    claseCaja.innerHTML += `<p>Contenido de Caja de Número: ${cajaDeNumero.obtenerValor()}</p>`;
}



// 11. Crea una función genérica 'identidad' que devuelva el mismo valor que recibe. Usa esta función para diferentes tipos y muestra los resultados en el HTML
const funcionGenerica = document.getElementById('funcionGenerica');

function identidad<T>(arg: T): T {
    return arg;
}

let tipoNumber = identidad<number>(22);
let tipoString = identidad<string>("Texto")

if (funcionGenerica) {
    funcionGenerica.innerHTML += `<p>Identidad del número: ${tipoNumber}</p>`
    funcionGenerica.innerHTML += `<p>Identidad del texto: ${tipoString}</p>`
}



// 12. Define una enumeración 'Color' con valores para diferentes colores. Usa esta enumeración para asignar un color favorito a una variable y muéstralo en el HTML
const enumColor = document.getElementById('enumColor') as HTMLElement;

enum Color {
    Azul = "Azul",
    Verde = "Verde",
    Rojo = "Rojo"
}

let colorFavorito: Color = Color.Verde;

if (enumColor) {
    enumColor.innerHTML += `<p>Color favorito: ${colorFavorito}</p>`;
}