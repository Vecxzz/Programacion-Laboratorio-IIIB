// 2. Crea un proyecto
console.log("Ejercicio 2: corriendo desde TypeScript");
// 3. Crea variables de diferentes tipos de datos (string, number, boolean, Date). Muestra sus valores en el HTML
var texto = "Hola, TypeScript!";
var numero = 123;
var booleano = true;
var fecha = (new Date()).getDate() + '/' + ((new Date()).getMonth() + 1) + '/' + (new Date()).getFullYear();
var variables = document.getElementById('variables');
if (variables) {
    variables.innerHTML += "<p>Texto: ".concat(texto, "</p>");
    variables.innerHTML += "<p>N\u00FAmero: ".concat(numero, "</p>");
    variables.innerHTML += "<p>Booleano: ".concat(booleano, "</p>");
    variables.innerHTML += "<p>Fecha: ".concat(fecha, "</p>");
}
// 4. Crea una función que convierta un número a una cadena de texto. Muestra el resultado en el HTML
var convertir = document.getElementById('convertir');
function convertirCadena() {
    var _a;
    return (_a = (prompt("Ingresa un número"))) === null || _a === void 0 ? void 0 : _a.toString();
}
if (convertir) {
    convertir.innerHTML += "<p>N\u00FAmero convertido a cadena: ".concat(convertirCadena(), "</p>");
}
// 5. Crea un array de números y una función que sume todos los elementos del array. Muestra la suma en el HTML
var sumar = document.getElementById('sumar');
var numeros = [10, 10, 2];
function sumarNumeros(numeros) {
    var total = 0;
    for (var _i = 0, numeros_1 = numeros; _i < numeros_1.length; _i++) {
        var numero_1 = numeros_1[_i];
        total += numero_1;
    }
    return total;
}
if (sumar) {
    sumar.innerHTML += "<p>Suma del array: ".concat(sumarNumeros(numeros), "</p>");
}
// 6. Crea un objeto que representa a un estudiante con nombre, edad y curso. Muestra al estudiante y sus propiedades en el HTML
var objetoEstudiante = document.getElementById('objetoEstudiante');
var estudiante1 = {
    nombre: "Juan",
    edad: 20,
    curso: "Matemáticas"
};
if (objetoEstudiante) {
    objetoEstudiante.innerHTML += "<p>Estudiante: ".concat(estudiante1.nombre, "</p>");
    objetoEstudiante.innerHTML += "<p>Edad: ".concat(estudiante1.edad, "</p>");
    objetoEstudiante.innerHTML += "<p>Curso: ".concat(estudiante1.curso, "</p>");
}
// 7. Define un "type" personalizado para representar una dirección con calle, ciudad y código postal. Usa este tipo para crear una dirección y muéstrala en el HTML
var objetoDireccion = document.getElementById('objetoDireccion');
var direccion1 = {
    calle: "Av. Principal",
    ciudad: "Mendoza",
    codigoPostal: "M5523"
};
if (objetoDireccion) {
    objetoDireccion.innerHTML += "<p>Direcci\u00F3n: ".concat(direccion1.calle, ", ").concat(direccion1.ciudad, ", ").concat(direccion1.codigoPostal, "</p>");
}
// 8. Define una interfaz para un usuario que tenga nombre, correo y un método para saludar. Implementa esta interfaz en un objeto y muestra el saludo en el HTML
var interfazUsuario = document.getElementById('interfazUsuario');
var UsuarioImplementado = /** @class */ (function () {
    function UsuarioImplementado(nombre, correo) {
        this.nombre = nombre;
        this.correo = correo;
    }
    UsuarioImplementado.prototype.saludar = function () {
        return "Hola, mi nombre es ".concat(this.nombre);
    };
    return UsuarioImplementado;
}());
var usuario1 = new UsuarioImplementado("Uriel", "urielvera47@gmail.com");
if (interfazUsuario) {
    interfazUsuario.innerHTML += "<p>".concat(usuario1.saludar(), "</p>");
}
// 9. Crea una clase 'Persona' con propiedades para nombre y edad. Implementa un método para presentarse y muestra el resultado en el HTML
var clasePersona = document.getElementById('clasePersona');
var Persona = /** @class */ (function () {
    function Persona(nombre, edad) {
        this.nombre = nombre;
        this.edad = edad;
    }
    Persona.prototype.presentarse = function () {
        return "Hola, mi nombre es ".concat(this.nombre, " y tengo ").concat(this.edad, " a\u00F1os");
    };
    return Persona;
}());
var persona1 = new Persona("Uriel", 19);
if (clasePersona) {
    clasePersona.innerHTML += "<p>".concat(persona1.presentarse(), "</p>");
}
// 10. Crea una clase genérica 'Caja' que almacena un valor de tipo genérico. Implementa un método para obtener el valor y muestra los resultados en el HTML
var claseCaja = document.getElementById('claseCaja');
var Caja = /** @class */ (function () {
    function Caja(valor) {
        this.valor = valor;
    }
    Caja.prototype.obtenerValor = function () {
        return this.valor;
    };
    return Caja;
}());
var cajaDeTexto = new Caja("Mensaje Secreto");
var cajaDeNumero = new Caja(22);
if (claseCaja) {
    claseCaja.innerHTML += "<p>Contenido de Caja de Texto: ".concat(cajaDeTexto.obtenerValor(), "</p>");
    claseCaja.innerHTML += "<p>Contenido de Caja de N\u00FAmero: ".concat(cajaDeNumero.obtenerValor(), "</p>");
}
// 11. Crea una función genérica 'identidad' que devuelva el mismo valor que recibe. Usa esta función para diferentes tipos y muestra los resultados en el HTML
var funcionGenerica = document.getElementById('funcionGenerica');
function identidad(arg) {
    return arg;
}
var tipoNumber = identidad(22);
var tipoString = identidad("Texto");
if (funcionGenerica) {
    funcionGenerica.innerHTML += "<p>Identidad del n\u00FAmero: ".concat(tipoNumber, "</p>");
    funcionGenerica.innerHTML += "<p>Identidad del texto: ".concat(tipoString, "</p>");
}
// 12. Define una enumeración 'Color' con valores para diferentes colores. Usa esta enumeración para asignar un color favorito a una variable y muéstralo en el HTML
var enumColor = document.getElementById('enumColor');
var Color;
(function (Color) {
    Color["Azul"] = "Azul";
    Color["Verde"] = "Verde";
    Color["Rojo"] = "Rojo";
})(Color || (Color = {}));
var colorFavorito = Color.Verde;
if (enumColor) {
    enumColor.innerHTML += "<p>Color favorito: ".concat(colorFavorito, "</p>");
}
