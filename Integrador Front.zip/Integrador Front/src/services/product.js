import { productoActivo } from "../../main";
import { closeModal } from "../views/modal"; // Cambiar el origen a modal.js
import { setInLocalStorage } from "../persistence/localStorage";
import { handleGetProductLocalStorage } from "../persistence/localStorage";
import { handleGetProductsToStore, handleRenderList } from "../views/store";
import Swal from "sweetalert2";

// PRODUCTOS

// GUARDAR
const acceptButton = document.getElementById("acceptButton");
acceptButton.addEventListener("click", () => {
  handleSaveOrModifyElements();
});

// FUNCIÓN GUARDAR
const handleSaveOrModifyElements = () => {
  const nombre = document.getElementById("nombre").value,
    imagen = document.getElementById("img").value,
    precio = document.getElementById("precio").value,
    categories = document.getElementById("categoria").value;
  let object = null;

  if (productoActivo) {
    object = {
      ...productoActivo,
      nombre,
      imagen,
      precio,
      categories,
    };
  } else {
    object = {
      id: new Date().toISOString(),
      nombre,
      imagen,
      precio,
      categories,
    };
  }
  Swal.fire({
    title: "Correcto",
    text: "Has agregado un nuevo producto",
    icon: "success"
  });

  setInLocalStorage(object);
  handleGetProductsToStore();
  closeModal();
};

// Eliminar elemento
export const handleDeleteProduct = () => {
  Swal.fire({
    title: "¿Deseas eliminar el producto?",
    text: "Si lo eliminas sera permanente",
    icon: "warning",
    showCancelButton: true,
    confirmButtonColor: "#3085d6",
    cancelButtonColor: "#d33",
    confirmButtonText: "Si, eliminar",
    cancelButtonText: "Cancelar",
  }).then((result) => {
    if (result.isConfirmed) {
      Swal.fire({
        title: "Producto eliminado con exito",
        text: "El producto ha sido correctamente eliminado",
        icon: "success",
      });
      const products = handleGetProductLocalStorage();
      const result = products.filter((el) => el.id !== productoActivo.id);
      localStorage.setItem("products", JSON.stringify(result));

      handleGetProductsToStore();
      closeModal(); 
    } else {
        closeModal();
    }
  });
};
