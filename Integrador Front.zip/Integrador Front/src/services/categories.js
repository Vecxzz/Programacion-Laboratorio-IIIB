import { categoriaActiva } from "../../main";
import { handleGetProductLocalStorage } from "../persistence/localStorage";
import { handleRenderList } from "../views/store";

// CATEGORIA
const handleFilterProductsByCategory = (categoryIn) => {
    const products = handleGetProductLocalStorage(); 

    if (categoryIn === "Todo") {
        handleRenderList(products);
    } else if (categoryIn === "mayorPrecio") {
        const sortedByHigherPrice = products.slice().sort((a, b) => b.precio - a.precio);
        handleRenderList(sortedByHigherPrice);
    } else if (categoryIn === "menorPrecio") {
        const sortedByLowerPrice = products.slice().sort((a, b) => a.precio - b.precio);
        handleRenderList(sortedByLowerPrice);
    } else {
        const result = products.filter((el) => el.categories === categoryIn);
        handleRenderList(result);
    }
};

//Render de la vista categorias
export const renderCategories = () => {

    //Tomamos elementos de la lista
    const ulList = document.getElementById("listFilter");

    //Creamos esos elementos dentro de la lista
    ulList.innerHTML = `
    <li id="Todo">Todos los productos</li>
    <li id="Hamburguesas">Hamburguesas</li>
    <li id="Papas">Papas</li>
    <li id="Gaseosas">Gaseosas</li>
    <li id="mayorPrecio">Mayor Precio</li>
    <li id="menorPrecio">Menor Precio</li>
    `;

    //Añadimos dinamicamente el evento click
    const liElements = ulList.querySelectorAll("li");
    liElements.forEach((liElement) => {
        liElement.addEventListener('click', () => {
            handleClick(liElement);
        });
    });

    //Verificamos y manejamos el estilo del evento activo
    const handleClick = (elemento) => {
        handleFilterProductsByCategory(elemento.id); 
        liElements.forEach((el) => {
            el.classList.remove('liActive'); 
        });
        elemento.classList.add('liActive'); 
    };
};